package database;

public interface DBScheme {
    String USER = "martinezseguratony";
    String PASS = "mongo";
}
